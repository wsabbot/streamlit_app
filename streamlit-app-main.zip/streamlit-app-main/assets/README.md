This directory has assets such as images.

Note that the main image 'mca_process.png' is created in MS PowerPoint from 'mca_process.pptx'. This image can be updated by updating this PowerPoint file.
